# Mob Fusion — Fabric 1.20.1

Mod untuk Minecraft Java 1.20.1 + Fabric. Mod ini menyediakan 22 pasangan fusion. Ketika dua mob yang cocok didorong hingga berada sangat dekat dengan kepala piston yang sedang memanjang, keduanya berubah menjadi satu Fusion Mob.

## Daftar 22 fusion

| Mob pertama | Mob kedua | Hasil fusion |
|---|---|---|
| Donkey | Horse | Donse Horse |
| Sheep | Cow | Cosheep Cow |
| Slime | Magma Cube | Magma Slime |
| Chicken | Rabbit | Chickit |
| Pig | Wolf | Pigdog |
| Fox | Cat | Foxcat |
| Bee | Parrot | Parabee |
| Dolphin | Turtle | Dolphurtle |
| Polar Bear | Panda | Pandabear |
| Camel | Llama | Camellama |
| Goat | Sheep | Goateep |
| Mooshroom | Cow | Mooshroom Cow |
| Iron Golem | Snow Golem | Frost Golem |
| Creeper | Skeleton | Skreeper |
| Zombie | Husk | Huskombie |
| Spider | Cave Spider | Cave Weaver |
| Enderman | Shulker | Endulker |
| Blaze | Ghast | Blazghast |
| Witch | Vindicator | Witchdicator |
| Strider | Hoglin | Hogstrider |
| Bat | Allay | Batllay |
| Axolotl | Frog | Froxolotl |

## Cara fusion di dalam game

1. Pastikan Fabric Loader, Fabric API, dan mod ini terpasang pada Minecraft Java 1.20.1.
2. Letakkan sebuah piston atau sticky piston menghadap ke area tempat dua mob berada.
3. Arahkan dua mob yang cocok agar berkumpul tepat di sekitar kepala piston.
4. Aktifkan piston. Saat piston berada dalam keadaan memanjang dan kedua mob cukup dekat, keduanya akan berubah menjadi satu fusion mob.

Pemeriksaan dilakukan di sekitar pemain setiap 2 tick supaya tidak perlu memindai seluruh dunia setiap tick. Fusion mob akan mendapat nama, partikel, dan suara kemunculan khusus.

## Build melalui GitHub Actions

1. Upload seluruh isi folder proyek ini ke repository GitHub.
2. Buka tab **Actions**.
3. Pilih workflow **Build Mob Fusion**.
4. Jalankan **Run workflow** atau lakukan push commit.
5. Buka hasil workflow yang selesai, lalu unduh artifact `MobFusion-Fabric-1.20.1`.
6. Di dalam artifact terdapat file `.jar`. Masukkan file tersebut ke folder `mods` Minecraft.

## Build lokal

Gunakan Java 17 dan Gradle 8.6, lalu jalankan:

```bash
gradle build
```

JAR hasil build ada di `build/libs/`.

## Catatan

- Target proyek ini khusus Minecraft Java 1.20.1 dengan Fabric.
- Ini adalah satu tipe entity dengan 22 varian visual/label, bukan 22 registry entity terpisah.
- Fusion hanya berjalan untuk pasangan yang terdaftar di tabel.
- Jika dua mob tidak berubah, pastikan piston benar-benar sedang memanjang, keduanya berada dekat kepala piston, dan pasangan mob termasuk daftar resep.
