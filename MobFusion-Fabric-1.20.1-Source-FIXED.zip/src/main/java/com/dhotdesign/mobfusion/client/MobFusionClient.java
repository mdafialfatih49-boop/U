package com.dhotdesign.mobfusion.client;

import com.dhotdesign.mobfusion.MobFusionMod;
import com.dhotdesign.mobfusion.client.model.FusionModel;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class MobFusionClient implements ClientModInitializer {
    public static final EntityModelLayer FUSION_LAYER = new EntityModelLayer(
            new Identifier(MobFusionMod.MOD_ID, "fusion_mob"), "main"
    );

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(FUSION_LAYER, FusionModel::getTexturedModelData);
        EntityRendererRegistry.register(MobFusionMod.FUSION_MOB, FusionRenderer::new);
    }
}
