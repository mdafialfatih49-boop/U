package com.dhotdesign.mobfusion.client;

import com.dhotdesign.mobfusion.MobFusionMod;
import com.dhotdesign.mobfusion.client.model.FusionModel;
import com.dhotdesign.mobfusion.entity.FusionMobEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class FusionRenderer extends MobEntityRenderer<FusionMobEntity, FusionModel> {
    public FusionRenderer(EntityRendererFactory.Context context) {
        super(context, new FusionModel(context.getPart(MobFusionClient.FUSION_LAYER)), 0.7F);
    }

    @Override
    public Identifier getTexture(FusionMobEntity entity) {
        return new Identifier(MobFusionMod.MOD_ID, "textures/entity/" + entity.getVariant() + ".png");
    }
}
