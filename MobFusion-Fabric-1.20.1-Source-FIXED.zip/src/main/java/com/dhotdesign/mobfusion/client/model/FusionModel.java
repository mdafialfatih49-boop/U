package com.dhotdesign.mobfusion.client.model;

import com.dhotdesign.mobfusion.entity.FusionMobEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumer;

public class FusionModel extends EntityModel<FusionMobEntity> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart body;
    private final ModelPart legFrontLeft;
    private final ModelPart legFrontRight;
    private final ModelPart legBackLeft;
    private final ModelPart legBackRight;
    private final ModelPart ears;
    private final ModelPart horns;
    private final ModelPart wool;
    private final ModelPart wings;
    private final ModelPart shell;
    private final ModelPart fins;
    private final ModelPart spikes;
    private final ModelPart tail;
    private final ModelPart eyes;

    public FusionModel(ModelPart bakedRoot) {
        super(RenderLayer::getEntityCutoutNoCull);
        this.root = bakedRoot.getChild("root");
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.legFrontLeft = root.getChild("front_left_leg");
        this.legFrontRight = root.getChild("front_right_leg");
        this.legBackLeft = root.getChild("back_left_leg");
        this.legBackRight = root.getChild("back_right_leg");
        this.ears = head.getChild("ears");
        this.horns = head.getChild("horns");
        this.wool = root.getChild("wool");
        this.wings = root.getChild("wings");
        this.shell = root.getChild("shell");
        this.fins = root.getChild("fins");
        this.spikes = root.getChild("spikes");
        this.tail = root.getChild("tail");
        this.eyes = head.getChild("eyes");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot().addChild("root", ModelPartBuilder.create(), ModelTransform.NONE);

        root.addChild("body", ModelPartBuilder.create().uv(0, 0)
                .cuboid(-5.0F, -4.0F, -7.0F, 10.0F, 8.0F, 14.0F),
                ModelTransform.pivot(0.0F, 13.0F, 0.0F));
        ModelPartData head = root.addChild("head", ModelPartBuilder.create().uv(0, 0)
                .cuboid(-3.0F, -3.0F, -5.0F, 6.0F, 6.0F, 6.0F)
                .cuboid("muzzle", -2.0F, -1.0F, -7.0F, 4.0F, 3.0F, 3.0F),
                ModelTransform.pivot(0.0F, 10.0F, -7.0F));
        head.addChild("ears", ModelPartBuilder.create().uv(32, 0)
                .cuboid(-3.0F, -7.0F, -1.0F, 2.0F, 7.0F, 2.0F)
                .cuboid(1.0F, -7.0F, -1.0F, 2.0F, 7.0F, 2.0F),
                ModelTransform.pivot(0.0F, -2.0F, -3.0F));
        head.addChild("horns", ModelPartBuilder.create().uv(32, 0)
                .cuboid(-4.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F)
                .cuboid(2.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                ModelTransform.pivot(0.0F, -2.0F, -4.0F));
        head.addChild("eyes", ModelPartBuilder.create().uv(48, 48)
                .cuboid(-2.6F, -1.5F, -5.2F, 1.0F, 1.0F, 0.5F)
                .cuboid(1.6F, -1.5F, -5.2F, 1.0F, 1.0F, 0.5F),
                ModelTransform.NONE);

        root.addChild("front_left_leg", ModelPartBuilder.create().uv(0, 0)
                .cuboid(-1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                ModelTransform.pivot(3.0F, 17.0F, -4.5F));
        root.addChild("front_right_leg", ModelPartBuilder.create().uv(0, 0)
                .cuboid(-1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                ModelTransform.pivot(-3.0F, 17.0F, -4.5F));
        root.addChild("back_left_leg", ModelPartBuilder.create().uv(0, 0)
                .cuboid(-1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                ModelTransform.pivot(3.0F, 17.0F, 4.5F));
        root.addChild("back_right_leg", ModelPartBuilder.create().uv(0, 0)
                .cuboid(-1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                ModelTransform.pivot(-3.0F, 17.0F, 4.5F));

        root.addChild("wool", ModelPartBuilder.create().uv(32, 0)
                .cuboid(-5.8F, -4.8F, -7.8F, 11.6F, 9.6F, 15.6F),
                ModelTransform.pivot(0.0F, 13.0F, 0.0F));
        root.addChild("wings", ModelPartBuilder.create().uv(32, 0)
                .cuboid(-8.0F, -1.0F, -3.0F, 3.0F, 2.0F, 8.0F)
                .cuboid(5.0F, -1.0F, -3.0F, 3.0F, 2.0F, 8.0F),
                ModelTransform.pivot(0.0F, 12.0F, 0.0F));
        root.addChild("shell", ModelPartBuilder.create().uv(32, 0)
                .cuboid(-5.8F, -5.5F, -5.0F, 11.6F, 4.0F, 11.0F),
                ModelTransform.pivot(0.0F, 12.0F, 0.0F));
        root.addChild("fins", ModelPartBuilder.create().uv(32, 0)
                .cuboid(-1.0F, -2.0F, 6.0F, 2.0F, 4.0F, 5.0F)
                .cuboid(-1.0F, -7.0F, -2.0F, 2.0F, 5.0F, 4.0F),
                ModelTransform.pivot(0.0F, 12.0F, 0.0F));
        root.addChild("spikes", ModelPartBuilder.create().uv(32, 0)
                .cuboid(-1.0F, -6.0F, -2.0F, 2.0F, 3.0F, 2.0F)
                .cuboid(-1.0F, -6.0F, 2.0F, 2.0F, 3.0F, 2.0F)
                .cuboid(-1.0F, -6.0F, 6.0F, 2.0F, 3.0F, 2.0F),
                ModelTransform.pivot(0.0F, 13.0F, 0.0F));
        root.addChild("tail", ModelPartBuilder.create().uv(32, 0)
                .cuboid(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 6.0F),
                ModelTransform.pivot(0.0F, 11.0F, 7.0F));

        return TexturedModelData.of(data, 64, 64);
    }

    @Override
    public void setAngles(FusionMobEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        String variant = entity.getVariant();
        head.yaw = headYaw * 0.017453292F;
        head.pitch = headPitch * 0.017453292F;
        legFrontLeft.pitch = (float) Math.cos(limbAngle * 0.6662F) * 1.4F * limbDistance;
        legBackRight.pitch = legFrontLeft.pitch;
        legFrontRight.pitch = (float) Math.cos(limbAngle * 0.6662F + Math.PI) * 1.4F * limbDistance;
        legBackLeft.pitch = legFrontRight.pitch;
        tail.pitch = 0.15F + (float) Math.sin(animationProgress * 0.12F) * 0.12F;

        ears.visible = variant.contains("horse") || variant.contains("donse") || variant.contains("chickit")
                || variant.contains("rabbit") || variant.contains("foxcat") || variant.contains("camellama");
        horns.visible = variant.contains("cow") || variant.contains("goat") || variant.contains("golem")
                || variant.contains("mooshroom") || variant.contains("pandabear");
        wool.visible = variant.contains("sheep") || variant.contains("goateep");
        wings.visible = variant.contains("parabee") || variant.contains("batllay") || variant.contains("blazghast");
        shell.visible = variant.contains("dolphurtle") || variant.contains("froxolotl");
        fins.visible = variant.contains("dolphurtle") || variant.contains("froxolotl");
        spikes.visible = variant.contains("skreeper") || variant.contains("cave_weaver") || variant.contains("endulker");
        eyes.visible = true;
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
