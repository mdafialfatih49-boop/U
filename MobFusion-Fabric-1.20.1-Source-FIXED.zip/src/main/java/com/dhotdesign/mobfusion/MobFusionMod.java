package com.dhotdesign.mobfusion;

import com.dhotdesign.mobfusion.entity.FusionEngine;
import com.dhotdesign.mobfusion.entity.FusionMobEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class MobFusionMod implements ModInitializer {
    public static final String MOD_ID = "mobfusion";

    public static final EntityType<FusionMobEntity> FUSION_MOB = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(MOD_ID, "fusion_mob"),
            EntityType.Builder.create(FusionMobEntity::new, SpawnGroup.CREATURE)
                    .setDimensions(1.35F, 1.35F)
                    .maxTrackingRange(10)
                    .trackingTickInterval(3)
                    .build("mobfusion:fusion_mob")
    );

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(FUSION_MOB, FusionMobEntity.createAttributes());
        ServerTickEvents.END_WORLD_TICK.register(FusionEngine::tick);
    }
}
