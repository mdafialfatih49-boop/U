package com.dhotdesign.mobfusion.entity;

import com.dhotdesign.mobfusion.MobFusionMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PistonBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public final class FusionEngine {
    private FusionEngine() {}

    private record Recipe(EntityType<?> first, EntityType<?> second, String variant, String displayName) {}

    private static final List<Recipe> RECIPES = List.of(
            new Recipe(EntityType.DONKEY, EntityType.HORSE, "donse_horse", "Donse Horse"),
            new Recipe(EntityType.SHEEP, EntityType.COW, "cosheep_cow", "Cosheep Cow"),
            new Recipe(EntityType.SLIME, EntityType.MAGMA_CUBE, "magma_slime", "Magma Slime"),
            new Recipe(EntityType.CHICKEN, EntityType.RABBIT, "chickit", "Chickit"),
            new Recipe(EntityType.PIG, EntityType.WOLF, "pigdog", "Pigdog"),
            new Recipe(EntityType.FOX, EntityType.CAT, "foxcat", "Foxcat"),
            new Recipe(EntityType.BEE, EntityType.PARROT, "parabee", "Parabee"),
            new Recipe(EntityType.DOLPHIN, EntityType.TURTLE, "dolphurtle", "Dolphurtle"),
            new Recipe(EntityType.POLAR_BEAR, EntityType.PANDA, "pandabear", "Pandabear"),
            new Recipe(EntityType.CAMEL, EntityType.LLAMA, "camellama", "Camellama"),
            new Recipe(EntityType.GOAT, EntityType.SHEEP, "goateep", "Goateep"),
            new Recipe(EntityType.MOOSHROOM, EntityType.COW, "mooshroom_cow", "Mooshroom Cow"),
            new Recipe(EntityType.IRON_GOLEM, EntityType.SNOW_GOLEM, "frost_golem", "Frost Golem"),
            new Recipe(EntityType.CREEPER, EntityType.SKELETON, "skreeper", "Skreeper"),
            new Recipe(EntityType.ZOMBIE, EntityType.HUSK, "huskombie", "Huskombie"),
            new Recipe(EntityType.SPIDER, EntityType.CAVE_SPIDER, "cave_weaver", "Cave Weaver"),
            new Recipe(EntityType.ENDERMAN, EntityType.SHULKER, "endulker", "Endulker"),
            new Recipe(EntityType.BLAZE, EntityType.GHAST, "blazghast", "Blazghast"),
            new Recipe(EntityType.WITCH, EntityType.VINDICATOR, "witchdicator", "Witchdicator"),
            new Recipe(EntityType.STRIDER, EntityType.HOGLIN, "hogstrider", "Hogstrider"),
            new Recipe(EntityType.BAT, EntityType.ALLAY, "batllay", "Batllay"),
            new Recipe(EntityType.AXOLOTL, EntityType.FROG, "froxolotl", "Froxolotl")
    );

    public static void tick(ServerWorld world) {
        // Scan only around players and every two ticks to catch short piston activations.
        if (world.getTime() % 2L != 0L || world.getPlayers().isEmpty()) return;

        for (PlayerEntity player : world.getPlayers()) {
            Box playerArea = player.getBoundingBox().expand(14.0D, 7.0D, 14.0D);
            List<MobEntity> nearbyMobs = world.getEntitiesByClass(
                    MobEntity.class,
                    playerArea,
                    mob -> mob.isAlive() && !(mob instanceof FusionMobEntity)
            );
            if (nearbyMobs.size() < 2) continue;

            for (MobEntity mob : nearbyMobs) {
                if (!mob.isAlive()) continue;
                BlockPos center = mob.getBlockPos();
                for (BlockPos pistonPos : BlockPos.iterate(
                        center.add(-3, -2, -3), center.add(3, 2, 3)
                )) {
                    BlockState state = world.getBlockState(pistonPos);
                    if (!(state.isOf(Blocks.PISTON) || state.isOf(Blocks.STICKY_PISTON))) continue;
                    if (!state.contains(PistonBlock.EXTENDED) || !state.get(PistonBlock.EXTENDED)) continue;

                    Direction facing = state.get(PistonBlock.FACING);
                    BlockPos headPos = pistonPos.offset(facing);
                    Box headArea = new Box(headPos).expand(1.15D, 1.0D, 1.15D);
                    List<MobEntity> candidates = world.getEntitiesByClass(
                            MobEntity.class,
                            headArea,
                            candidate -> candidate.isAlive() && !(candidate instanceof FusionMobEntity)
                    );
                    if (tryFuse(world, candidates)) return;
                }
            }
        }
    }

    private static boolean tryFuse(ServerWorld world, List<MobEntity> candidates) {
        for (int i = 0; i < candidates.size(); i++) {
            MobEntity first = candidates.get(i);
            if (!first.isAlive()) continue;
            for (int j = i + 1; j < candidates.size(); j++) {
                MobEntity second = candidates.get(j);
                if (!second.isAlive() || first.squaredDistanceTo(second) > 3.0D) continue;

                Recipe recipe = findRecipe(first.getType(), second.getType());
                if (recipe == null) continue;

                Vec3d middle = first.getPos().add(second.getPos()).multiply(0.5D);
                FusionMobEntity fusion = new FusionMobEntity(MobFusionMod.FUSION_MOB, world);
                fusion.refreshPositionAndAngles(middle.x, middle.y, middle.z, first.getYaw(), 0.0F);
                fusion.setVariant(recipe.variant());
                fusion.setCustomName(Text.literal(recipe.displayName()));
                fusion.setCustomNameVisible(true);
                fusion.setHealth(fusion.getMaxHealth());
                fusion.setPersistent();

                if (world.spawnEntity(fusion)) {
                    first.discard();
                    second.discard();
                    world.spawnParticles(ParticleTypes.HAPPY_VILLAGER,
                            middle.x, middle.y + 0.8D, middle.z, 22, 0.55D, 0.45D, 0.55D, 0.04D);
                    world.playSound(null, middle.x, middle.y, middle.z,
                            SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.NEUTRAL, 0.75F, 1.35F);
                    return true;
                }
            }
        }
        return false;
    }

    private static Recipe findRecipe(EntityType<?> a, EntityType<?> b) {
        for (Recipe recipe : RECIPES) {
            if ((recipe.first() == a && recipe.second() == b)
                    || (recipe.first() == b && recipe.second() == a)) {
                return recipe;
            }
        }
        return null;
    }
}
